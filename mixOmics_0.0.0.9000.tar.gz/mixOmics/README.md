# mixOmics
Shiny Interface of mixOmics R scripts
